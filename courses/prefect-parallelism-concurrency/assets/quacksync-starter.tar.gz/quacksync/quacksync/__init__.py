"""QuackSync package."""
