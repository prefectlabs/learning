"""Weather MCP Server - A FastMCP server for weather data and predictions."""

from .server import mcp

__all__ = ["mcp"]
