import requests
from datetime import datetime, timedelta
from typing import Optional
from fastmcp import FastMCP

mcp = FastMCP("Weather Probability Server 🌤️")

def _geocode_location(location: str) -> Optional[dict]:
    """Geocode a city name to get coordinates using Open-Meteo."""
    geocode_url = "https://geocoding-api.open-meteo.com/v1/search"
    params = {
        "name": location,
        "count": 1,
        "language": "en",
        "format": "json"
    }

    try:
        response = requests.get(geocode_url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()

        if not data.get("results"):
            return None

        result = data["results"][0]
        return {
            "latitude": result["latitude"],
            "longitude": result["longitude"],
            "name": result["name"],
            "country": result.get("country", "")
        }
    except Exception:
        return None

def _weather_code_to_description(code: int) -> str:
    """Convert WMO weather codes to readable descriptions."""
    weather_codes = {
        0: "Clear", 1: "Mainly Clear", 2: "Partly Cloudy", 3: "Overcast",
        45: "Foggy", 48: "Foggy", 51: "Light Drizzle", 53: "Drizzle",
        55: "Heavy Drizzle", 61: "Light Rain", 63: "Rain", 65: "Heavy Rain",
        71: "Light Snow", 73: "Snow", 75: "Heavy Snow", 77: "Snow Grains",
        80: "Light Showers", 81: "Showers", 82: "Heavy Showers",
        85: "Light Snow Showers", 86: "Snow Showers", 95: "Thunderstorm",
        96: "Thunderstorm with Hail", 99: "Thunderstorm with Hail"
    }
    return weather_codes.get(code, "Unknown")

def get_weather_forecast(location: str, days_ahead: int = 7) -> str:
    """Get weather forecast for a location up to 16 days ahead.

    Args:
        location: City name (e.g., "San Francisco" or "London, UK")
        days_ahead: Number of days to forecast (1-16, default: 7)

    Returns:
        Formatted forecast information with daily predictions
    """
    if days_ahead < 1 or days_ahead > 16:
        return "Error: days_ahead must be between 1 and 16"

    coords = _geocode_location(location)
    if not coords:
        return f"Error: Could not find location '{location}'"

    forecast_url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude": coords["latitude"],
        "longitude": coords["longitude"],
        "daily": "temperature_2m_max,temperature_2m_min,precipitation_sum,weather_code",
        "forecast_days": days_ahead,
        "temperature_unit": "fahrenheit",
        "precipitation_unit": "inch"
    }

    try:
        response = requests.get(forecast_url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()

        daily = data["daily"]
        forecast = f"Weather Forecast for {coords['name']}, {coords['country']} ({days_ahead} days):\n\n"

        for i in range(days_ahead):
            date = daily["time"][i]
            temp_max = daily["temperature_2m_max"][i]
            temp_min = daily["temperature_2m_min"][i]
            precip = daily["precipitation_sum"][i]
            weather_code = daily["weather_code"][i]
            conditions = _weather_code_to_description(weather_code)

            forecast += f"📅 {date}:\n"
            forecast += f"   🌡️  {temp_min}°F - {temp_max}°F\n"
            forecast += f"   ☁️  {conditions}\n"
            forecast += f"   💧 Precipitation: {precip} in\n\n"

        return forecast

    except Exception as e:
        return f"Error fetching forecast: {str(e)}"

def get_historical_weather(location: str, date: str) -> str:
    """Get historical weather for a specific date.

    Args:
        location: City name (e.g., "San Francisco" or "London, UK")
        date: Date in YYYY-MM-DD format (e.g., "2023-06-15")

    Returns:
        Historical weather data for that date
    """
    try:
        target_date = datetime.strptime(date, "%Y-%m-%d")
        if target_date > datetime.now():
            return f"Error: Date {date} is in the future. Use get_weather_forecast for future dates."

        # Historical data is typically available up to ~80 years back
        if target_date < datetime.now() - timedelta(days=365*80):
            return f"Error: Date {date} is too far in the past. Historical data available for ~80 years."

    except ValueError:
        return f"Error: Invalid date format '{date}'. Use YYYY-MM-DD format."

    coords = _geocode_location(location)
    if not coords:
        return f"Error: Could not find location '{location}'"

    historical_url = "https://archive-api.open-meteo.com/v1/archive"
    params = {
        "latitude": coords["latitude"],
        "longitude": coords["longitude"],
        "start_date": date,
        "end_date": date,
        "daily": "temperature_2m_max,temperature_2m_min,precipitation_sum,weather_code",
        "temperature_unit": "fahrenheit",
        "precipitation_unit": "inch"
    }

    try:
        response = requests.get(historical_url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()

        daily = data["daily"]
        temp_max = daily["temperature_2m_max"][0]
        temp_min = daily["temperature_2m_min"][0]
        precip = daily["precipitation_sum"][0]
        weather_code = daily["weather_code"][0]
        conditions = _weather_code_to_description(weather_code)

        result = f"Historical Weather for {coords['name']}, {coords['country']} on {date}:\n\n"
        result += f"🌡️  Temperature: {temp_min}°F - {temp_max}°F\n"
        result += f"☁️  Conditions: {conditions}\n"
        result += f"💧 Precipitation: {precip} in\n"

        if precip > 0:
            result += f"\n✅ It rained on this date ({precip} inches)"
        else:
            result += f"\n☀️  No precipitation on this date"

        return result

    except Exception as e:
        return f"Error fetching historical weather: {str(e)}"

def calculate_rain_probability(location: str, date: str) -> str:
    """Calculate probability of rain/precipitation for a future date.

    Combines historical patterns (from past years) with forecast data (if available)
    to provide a comprehensive rain probability assessment.

    Args:
        location: City name (e.g., "San Francisco" or "London, UK")
        date: Target date in YYYY-MM-DD format (e.g., "2024-06-15")

    Returns:
        Combined probability analysis with historical average, forecast (if available), and final probability
    """
    try:
        target_date = datetime.strptime(date, "%Y-%m-%d")
        today = datetime.now().date()
        target_date_only = target_date.date()

        if target_date_only < today:
            return f"Error: Date {date} is in the past. Use get_historical_weather for past dates."

        days_ahead = (target_date_only - today).days

        if days_ahead > 16:
            return f"Error: Date {date} is more than 16 days away. Forecast data only available up to 16 days."

    except ValueError:
        return f"Error: Invalid date format '{date}'. Use YYYY-MM-DD format."

    coords = _geocode_location(location)
    if not coords:
        return f"Error: Could not find location '{location}'"

    result = f"Rain Probability Analysis for {coords['name']}, {coords['country']} on {date}:\n\n"

    # Get historical data for the same date in past years
    historical_precip = []
    for year_offset in range(1, 6):  # Last 5 years
        try:
            historical_date = target_date.replace(year=target_date.year - year_offset)
            historical_date_str = historical_date.strftime("%Y-%m-%d")

            historical_url = "https://archive-api.open-meteo.com/v1/archive"
            params = {
                "latitude": coords["latitude"],
                "longitude": coords["longitude"],
                "start_date": historical_date_str,
                "end_date": historical_date_str,
                "daily": "precipitation_sum"
            }

            hist_response = requests.get(historical_url, params=params, timeout=10)
            if hist_response.status_code == 200:
                hist_data = hist_response.json()
                precip = hist_data["daily"]["precipitation_sum"][0]
                historical_precip.append(precip)
        except Exception:
            continue

    # Calculate historical probability
    if historical_precip:
        rainy_days = sum(1 for p in historical_precip if p > 0.01)  # > 0.01 inches = rain
        historical_prob = (rainy_days / len(historical_precip)) * 100
        avg_precip = sum(historical_precip) / len(historical_precip)

        result += f"📊 Historical Average (last {len(historical_precip)} years):\n"
        result += f"   • Rain probability: {historical_prob:.1f}%\n"
        result += f"   • Average precipitation: {avg_precip:.2f} in\n\n"
    else:
        historical_prob = None
        result += "📊 Historical data: Not available\n\n"

    # Get forecast if within 16 days
    forecast_precip = None
    if days_ahead <= 16:
        forecast_url = "https://api.open-meteo.com/v1/forecast"
        params = {
            "latitude": coords["latitude"],
            "longitude": coords["longitude"],
            "daily": "precipitation_sum",
            "forecast_days": min(days_ahead + 1, 16)
        }

        try:
            forecast_response = requests.get(forecast_url, params=params, timeout=10)
            if forecast_response.status_code == 200:
                forecast_data = forecast_response.json()
                forecast_precip = forecast_data["daily"]["precipitation_sum"][days_ahead]

                result += f"🔮 Forecast Prediction:\n"
                result += f"   • Expected precipitation: {forecast_precip:.2f} in\n"
                if forecast_precip > 0.01:
                    result += f"   • Forecast indicates: Rain likely\n\n"
                else:
                    result += f"   • Forecast indicates: No rain expected\n\n"
        except Exception:
            result += "🔮 Forecast data: Not available\n\n"

    # Calculate combined probability
    if historical_prob is not None and forecast_precip is not None:
        # Weight: 60% historical, 40% forecast
        forecast_weight = 0.4 if forecast_precip > 0.01 else 0.2
        historical_weight = 1 - forecast_weight

        combined_prob = (historical_prob * historical_weight) + (100 * forecast_weight if forecast_precip > 0.01 else 0)

        result += f"🎯 Combined Probability:\n"
        result += f"   • Rain probability: {combined_prob:.1f}%\n"
        result += f"   • Based on: {historical_weight*100:.0f}% historical patterns, {forecast_weight*100:.0f}% forecast\n\n"

        if combined_prob >= 70:
            result += "☔ High probability of rain - plan accordingly!"
        elif combined_prob >= 40:
            result += "🌦️  Moderate chance of rain - have a backup plan"
        else:
            result += "☀️  Low probability of rain - looks promising!"

    elif historical_prob is not None:
        result += f"🎯 Probability Assessment:\n"
        result += f"   • Rain probability: {historical_prob:.1f}% (based on historical data only)\n\n"

        if historical_prob >= 70:
            result += "☔ Historically rainy - plan accordingly!"
        elif historical_prob >= 40:
            result += "🌦️  Historically moderate chance - have a backup plan"
        else:
            result += "☀️  Historically low chance - looks promising!"
    else:
        result += "⚠️  Insufficient data for probability calculation"

    return result

if __name__ == "__main__":
    mcp.run()
